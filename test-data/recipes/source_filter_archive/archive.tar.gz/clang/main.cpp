clang content
